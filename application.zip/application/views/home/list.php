<?php
//load slider
include('slider.php');
//load kategori
// include('kategori.php');
//load data produk
include('produk.php');
//load berita
include('berita.php');
