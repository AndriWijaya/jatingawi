<h4 class="m-text14 p-b-7">
    Menu Pelanggan
</h4>

<ul class="p-b-54">
    <li class="p-t-4">
        <a href="<?= base_url('dashboard') ?>" class="s-text13 active1">
            <i class="fa fa-dashboard"></i> Dashboard
        </a>
    </li>

    <li class="p-t-4">
        <a href="<?= base_url('dashboard/profil') ?>" class="s-text13 active1">
            <i class="fa fa-user"></i> Profil Saya
        </a>
    </li>

    <li class="p-t-4">
        <a href="<?= base_url('belanja') ?>" class="s-text13 active1">
            <i class="fa fa-shopping-cart"></i> Keranjang Belanja
        </a>
    </li>

    <li class="p-t-4">
        <a href="<?= base_url('dashboard/belanja') ?>" class="s-text13 active1">
            <i class="fa fa-check"></i> Riwayat Belanja
        </a>
    </li>

    <li class="p-t-4">
        <a href="<?= base_url('masuk/logout') ?>" class="s-text13 active1">
            <i class="fa fa-sign-out"></i> Logout
        </a>
    </li>
</ul>