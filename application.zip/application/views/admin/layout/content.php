<?php
//Mengambil data isi content website di controller (dari variabel ISI)
if ($isi) {
    $this->load->view($isi);
}
